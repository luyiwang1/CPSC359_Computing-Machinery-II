Minh Hang Chu 30074056
CPSC 359 - Fall 2019- University of Calgary

This folder contains contents for Assignment 4.
The assignment is completed using sample codes from Tutorial Week 9 - TA Abdullah Sarhan - mainly from folder DrawingWithCharacterMovement

Assignment description from D2L:

Objective:
Your goal is to write a program, in C, that emulates an Etch A Sketch, a retro toy from the 1960s. Etch A Sketch allowed people to make rudimentary drawings with
a small set of simple functions. Although Etch A Sketch was a mechanical device, you can emulate its functions withsoftware on the RPi.

From a default starting position, the user moves the “pen” up/down/left/right to draw a picture. The user
can restart at any time by inverting the Etch A Sketch and shaking it to erase. After erasing drawing continues from the
last position of the pen.

The directory ASN4 should contain the following files:
- framebuffer.c
- framebuffer.h
- gpio.h
- link.ld
- mailbox.c
- mailbox.h
- main.c
- Makefile
- snes.c
- snes.h
- start.s
- systimer.c
- systimer.h
- uart.c
- uart.h

Open the folder, right click and choose `Open in terminal` and type `make all` to compile. This will generate kernel8.img file. Move this file to SD card for the Pi and plug it to the Board.
Plug in HDMI cord.
Plug power cord.

You will see a white background on screen. Use SNES to draw. Press "up", "down", "left", "right" to draw the black line.
Press Start to erase.

