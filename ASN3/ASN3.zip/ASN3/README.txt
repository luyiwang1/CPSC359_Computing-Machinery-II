Minh Hang Chu 30074056
CPSC 359 - Fall 2019- University of Calgary

This folder contains contents for Assignment 3: Basic GPIO and Interrupts.

Assignment description:

Objective:
Your goal is to write a program, inC, that illuminates three LEDs in a given pattern (order and duration).  The LEDpattern should change, as specified, in response to changes in the input.Table 1 lists the Raspberry Pi I/O pins that you will use. These are the pins corresponding to LEDs 1, 2, and 3, and inputs 1 and 2 on the ExplorerHat Pro boards in the lab. Note that all of the ExplorerHat inputs are pulled low.

There are two LED patterns that your program will produce. These are:

1.  The LEDs illuminate sequentially in the order: 1, 2, 3, 1, 2, 3, and so on. Each will be on for0.5s, then off fora delay of0.5s.

2.  The LEDs illuminate sequentially in the order : 3, 2, 1, 3, 2, 1, and so on. Each will be on for0.25s, then off fora delay of0.25s. I.e., the reverse order of the first pattern, and faster.

When your program starts, it should illuminate the LEDs in the first pattern. Upon receiving an interrupt fromSwitchA, the LEDs should change to the second illumination pattern.  Similarly, when your program receives an interrupt from Switch B the LEDs should change to the first pattern. 

The directory ASM3 should contain the following files:
- gpio.h
- handlers.c
- handlers.o
- irq.h
- link.ld
- main.c
- Makefile
- startV2.s
- sysreg.s
- systimer.c
- systimer.h
- uart.c
- uart.h

Open the folder, right click and choose `Open in terminal` and type `make all` to compile. This will generate kernel8.img file. Move this file to SD card for the Pi and plug it to the Explorer Hat.
Plug power cord.

You will see:
- Sequence 1,2,3 lights will start with 0.5s on anf off each. Press button of PIN 23 will not change anything.
- Press button PIN 22 to switch sequence, it will show light 3,2,1 with 0.25s on and off.
- Press button PIN 23 to switch sequence 1,2,3.
- Continue press button to switch and see the light sequence.

