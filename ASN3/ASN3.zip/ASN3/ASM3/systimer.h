// Function prototypes
unsigned long get_timer_counter();
void microsecond_delay(unsigned int interval);
